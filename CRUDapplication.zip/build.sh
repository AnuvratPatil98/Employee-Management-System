set -0 errexit

pip install --upgrade pip
pip install -r requirement.txt